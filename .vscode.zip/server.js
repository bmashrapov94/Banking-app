const express = require('express');
const exhbs = require("express-handlebars");
const path = require("path");
const session = require("express-session");
const bcrypt = require("bcrypt");
const mongoose = require("mongoose");
const Client = require("./models/Client"); // Ensure this model is correctly defined for your schema
require("dotenv").config();
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;

// Helper function to read user data
const readUserData = () => {
  const jsonData = fs.readFileSync(path.join(__dirname, "user.json"), "utf8");
  return JSON.parse(jsonData);
};

mongoose
  .connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true,
  })
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => console.log(err));

app.engine(
  "hbs",
  exhbs({
    extname: "hbs",
    defaultLayout: false,
    layoutsDir: path.join(__dirname, "views/layouts"),
  })
);
app.set("view engine", "hbs");
app.set("views", path.join(__dirname, "views"));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use("/public", express.static(path.join(__dirname, "public")));
app.use(
  session({
    secret: process.env.SESSION_SECRET,
    resave: true,
    saveUninitialized: false,
    cookie: { httpOnly: true, secure: true },
  })
);

// Login Route
app.get("/", (req, res) => {
  res.render("login", { errorMessage: null });
});

app.post("/login", async (req, res) => {
  try {
    const userData = readUserData(); // Read user data from the JSON file
    const clientInfo = userData[req.body.username]; // Access the user's information

    console.log("userData:", userData);
    console.log("req.body.username:", req.body.username);
    console.log("req.body.password:", req.body.password);
    console.log("clientInfo:", clientInfo);

    if (
      !clientInfo ||
      !(await bcrypt.compare(req.body.password, clientInfo.password))
    ) {
      return res.render("login", { errorMessage: "Invalid credentials" });
    }

    // If the client is found and the password matches
    req.session.isAuthenticated = true;
    req.session.username = req.body.username; // Use the username from the request body
    res.redirect("/main");
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

// Registration Route
app.get("/register", (req, res) => {
  let successMessage = req.query.success ? "Successfully registered!" : null;
  let errorMessage = req.query.error || null;

  res.render("register", {
    successMessage: successMessage,
    errorMessage: errorMessage,
  });
});

app.post("/register", async (req, res) => {
  const { username, password } = req.body;

  try {
    let client = await Client.findOne({ username: username });
    if (client) {
      return res.redirect("/register?error=User already exists.");
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    client = new Client({ username, password: hashedPassword });
    await client.save();

    res.redirect("/register?success=true");
  } catch (error) {
    console.error(error);
    res.status(500).send("Server error");
  }
});

// Balance Route
app.get("/balance", async (req, res) => {
  if (req.session.isAuthenticated) {
    try {
      const client = await Client.findOne({ username: req.session.username });
      if (!client) {
        return res.redirect("/main");
      }
      res.render("balance", {
        username: req.session.username,
        balance: client.balance,
      });
    } catch (error) {
      console.error(error);
      res.status(500).send("Server error");
    }
  } else {
    res.redirect("/");
  }
});

app.post("/balance", (req, res) => {
  if (req.session.isAuthenticated) {
    const accountID =
      req.body.accountNumber || req.session.actionData.accountNumber;
    const accountData = readAccountsData();

    if (accountData[accountID]) {
      res.redirect(`/balance?accountNumber=${encodeURIComponent(accountID)}`);
    } else {
      req.session.errorMessage = "Invalid account number";
      res.redirect("/main");
    }
  } else {
    res.redirect("/");
  }
});

// Deposit Route
app.get("/deposit", async (req, res) => {
  if (req.session.isAuthenticated) {
    const username = req.session.username;

    try {
      const client = await Client.findOne({ username: username });
      const accounts = [];
      if (client.chequing)
        accounts.push({ type: "Chequing", number: client.chequing });
      if (client.savings)
        accounts.push({ type: "Savings", number: client.savings });

      res.render("deposit", { username, accounts });
    } catch (error) {
      console.error(error);
      res.status(500).send("Server error");
    }
  } else {
    res.redirect("/");
  }
});

app.post("/deposit", async (req, res) => {
  if (req.session.isAuthenticated) {
    const { depositAmount } = req.body;
    try {
      const client = await Client.findOne({ username: req.session.username });
      if (!client) {
        return res.redirect("/main");
      }

      client.balance += parseFloat(depositAmount);
      await client.save();

      res.redirect("/balance");
    } catch (error) {
      console.error(error);
      res.status(500).send("Server error");
    }
  } else {
    res.redirect("/");
  }
});

// Withdrawal Route
app.get("/withdrawal", async (req, res) => {
  if (req.session.isAuthenticated) {
    const username = req.session.username;

    try {
      const client = await Client.findOne({ username: username });
      const accounts = [];
      if (client.chequing)
        accounts.push({ type: "Chequing", number: client.chequing });
      if (client.savings)
        accounts.push({ type: "Savings", number: client.savings });

      res.render("withdrawal", { username, accounts });
    } catch (error) {
      console.error(error);
      res.status(500).send("Server error");
    }
  } else {
    res.redirect("/");
  }
});

app.post("/withdrawal", async (req, res) => {
  if (req.session.isAuthenticated) {
    const { withdrawalAmount } = req.body;
    try {
      const client = await Client.findOne({ username: req.session.username });
      if (!client || client.balance < withdrawalAmount) {
        return res.redirect("/main");
      }

      client.balance -= parseFloat(withdrawalAmount);
      await client.save();

      res.redirect("/balance");
    } catch (error) {
      console.error(error);
      res.status(500).send("Server error");
    }
  } else {
    res.redirect("/");
  }
});

// Main Route
app.get("/main", (req, res) => {
  if (req.session.isAuthenticated) {
    res.render("main", { username: req.session.username });
  } else {
    res.redirect("/");
  }
});

// Logout Route
app.get("/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/");
  });
});

// Open Account page

// Function to read the current accounts data from the JSON file
function readAccountsData() {
  return JSON.parse(fs.readFileSync("account.json", "utf8"));
}

// Function to write updated accounts data to the JSON file
function writeAccountsData(data) {
  fs.writeFileSync("account.json", JSON.stringify(data, null, 2), "utf8");
}

//new code for opening account
app.post("/openAccount", async (req, res) => {
  // Check if the user is authenticated
  if (req.session.isAuthenticated) {
    const username = req.session.username;
    const accountType = req.body.accountType; // 'Chequing' or 'Savings'

    try {
      const client = await Client.findOne({ username: username });

      // Check if the client exists
      if (!client) {
        req.session.errorMessage = "Client not found.";
        return res.redirect("/openAccount");
      }

      // Check if the client already has this type of account
      if (
        (accountType === "Chequing" && client.chequing) ||
        (accountType === "Savings" && client.savings)
      ) {
        req.session.errorMessage =
          "You already have a " + accountType + " account.";
        return res.redirect("/openAccount");
      }

      // Generate a new account number
      const newAccountNumber = await generateNewAccountNumber(); // Implement this function

      // Update the client document with the new account
      if (accountType === "Chequing") {
        client.chequing = newAccountNumber;
      } else {
        // 'Savings'
        client.savings = newAccountNumber;
      }
      await client.save();

      req.session.successMessage =
        accountType +
        " account created successfully. Account Number: " +
        newAccountNumber;
      return res.redirect("/main");
    } catch (error) {
      console.error(error);
      req.session.errorMessage =
        "An error occurred while creating the account.";
      res.redirect("/openAccount");
    }
  } else {
    // User is not authenticated
    res.redirect("/");
  }
});

async function generateNewAccountNumber() {
  // Assume there's a model or method to get and update the last account number
  // For example, using a hypothetical 'Settings' model
  const settings = await Settings.findOne({ name: "lastAccountNumber" });

  if (!settings) {
    // Handle the case where the setting doesn't exist yet
    const newSetting = new Settings({
      name: "lastAccountNumber",
      value: "1000000",
    });
    await newSetting.save();
    return newSetting.value;
  }

  // Increment the last account number and save it
  let lastNumber = parseInt(settings.value, 10);
  lastNumber += 1;
  settings.value = lastNumber.toString().padStart(7, "0");
  await settings.save();

  return settings.value;
}

app.get("/openAccount", (req, res) => {
  if (req.session.isAuthenticated) {
    res.render("openAccount", { username: req.session.username });
  } else {
    res.redirect("/");
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
